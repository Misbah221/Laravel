<?php $__env->startSection('content'); ?>
<div class="container">
 <!-- kategori produk -->
 <div class="row mt-4">
    <div class="col col-md-12 col-sm-12 mb-4">
      <h2 class="text-center">Kategori Produk</h2>
    </div>
    <!-- kategori pertama -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="<?php echo e(URL::to('kategori/satu')); ?>">
          <img src="<?php echo e(asset('slide4.jpg')); ?>" alt="foto kategori" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="<?php echo e(URL::to('kategori/satu')); ?>" class="text-decoration-none">
            <p class="card-text"> تفسير جلالين</p>
          </a>
        </div>
      </div>
    </div>
    <!-- kategori kedua -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="<?php echo e(URL::to('kategori/dua')); ?>">
          <img src="<?php echo e(asset('slide5.jfif')); ?>" alt="foto kategori" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="<?php echo e(URL::to('kategori/dua')); ?>" class="text-decoration-none">
            <p class="card-text">فقه مذاهب الأربعة </p>
          </a>
        </div>
      </div>
    </div>
    <!-- kategori ketiga -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="https://wa.me/085715391779">
          <img src="<?php echo e(asset('slide6.jfif')); ?>" alt="foto kategori" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="https://wa.me/085715391779" class="text-decoration-none">
            <p class="card-text">حلية الأولياء</p>
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- end kategori produk -->
  <!-- produk Terbaru-->
  <div class="row mt-4">
    <div class="col col-md-12 col-sm-12 mb-4">
      <h2 class="text-center">Terbaru</h2>
    </div>
    <!-- produk pertama -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="https://wa.me/085715391779">
          <img src="<?php echo e(asset('slide7.jpg')); ?>" alt="foto produk" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="https://wa.me/085715391779" class="text-decoration-none">
            <p class="card-text">
              Produk Pertama
            </p>
          </a>
          <div class="row mt-4">
            <div class="col">
              <button class="btn btn-light">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <div class="col-auto">
              <p>
                Rp. 10.000,00
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- produk kedua -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="https://wa.me/085715391779">
          <img src="<?php echo e(asset('slide8.webp')); ?>" alt="foto produk" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="https://wa.me/085715391779" class="text-decoration-none">
            <p class="card-text">
              Produk Kedua
            </p>
          </a>
          <div class="row mt-4">
            <div class="col">
              <button class="btn btn-light">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <div class="col-auto">
              <p>
                Rp. 10.000,00
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- produk ketiga -->
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <a href="https://wa.me/085715391779">
          <img src="<?php echo e(asset('slide9.webp')); ?>" alt="foto produk" class="card-img-top">
        </a>
        <div class="card-body">
          <a href="https://wa.me/085715391779" class="text-decoration-none">
            <p class="card-text">
              Produk Ketiga
            </p>
          </a>
          <div class="row mt-4">
            <div class="col">
              <button class="btn btn-light">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <div class="col-auto">
              <p>
                Rp. 10.000,00
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end produk terbaru -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\APLIKASI\toko\resources\views/homepage/kategori.blade.php ENDPATH**/ ?>