<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- table slideshow -->
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Slideshow</h4>
        </div>
        <div class="card-body">
          <?php if($message = Session::get('error')): ?>
              <div class="alert alert-warning">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="50px">No</th>
                  <th>Gambar</th>
                  <th>Title</th>
                  <th>content</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $itemslideshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                  <?php echo e(++$no); ?>

                  </td>
                  <td>
                    <?php if($slide->foto != null): ?>
                    <img src="<?php echo e(\Storage::url($slide->foto)); ?>" alt="<?php echo e($slide->caption_title); ?>" width='150px' class="img-thumbnail">
                    <?php endif; ?>
                  </td>
                  <td>
                  <?php echo e($slide->caption_title); ?>

                  </td>
                  <td>
                  <?php echo e($slide->caption_content); ?>

                  </td>
                  <td>
                    <form action="<?php echo e(route('slideshow.destroy', $slide->id)); ?>" method="post" style="display:inline;">
                      <?php echo csrf_field(); ?>
                      <?php echo e(method_field('delete')); ?>

                      <button type="submit" class="btn btn-sm btn-danger mb-2">
                        Hapus
                      </button>                    
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($itemslideshow->links()); ?>

          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-4">
              <form action="<?php echo e(url('/admin/slideshow')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="foto">Foto</label>
                  <br />
                  <input type="file" name="image" id="image">
                </div>
                <div class="form-group">
                  <label for="caption_title">Title</label>
                  <input type="text" name="caption_title" class="form-control">
                </div>
                <div class="form-group">
                  <label for="caption_content">Content</label>
                  <textarea name="caption_content" id="caption_content" rows="3" class="form-control"></textarea>
                </div>
                <div class="form-group">
                  <button class="btn btn-primary">Upload</button>
                </div>
              </form>
            
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\latihan edit\toko\resources\views/slideshow/index.blade.php ENDPATH**/ ?>