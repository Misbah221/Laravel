<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col">
      <h1>Kontak Kami</h1>
      <h3>No Wa : 0857-1539-1779</h3>
      <h3>IG    : fuadz</h3>
      <h3>FB    : Misbakhul Fuad</h3>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\APLIKASI\toko\resources\views/homepage/kontak.blade.php ENDPATH**/ ?>