<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Image</h3>
        </div>
        <div class="card-body">
          <form action="<?php echo e(url('/admin/image')); ?>" method="post" enctype="multipart/form-data" class="form-inline">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <input type="file" name="image" id="image">
          </div>
          <div class="form-group">
            <button class="btn btn-primary">Upload</button>
          </div>
          </form>
        </div>
        <div class="card-body">
          <?php if(count($errors) > 0): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-warning"><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <?php if($message = Session::get('error')): ?>
              <div class="alert alert-warning">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <div class="row">
            <?php $__currentLoopData = $itemgambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gambar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col col-lg-3 col-md-3 mb-2">
              <img src="<?php echo e(\Storage::url($gambar->url)); ?>" alt="img" class="img-thumbnail mb-2">
              <form action="<?php echo e(url('/admin/image/'.$gambar->id)); ?>" method="post" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('delete')); ?>

                <button type="submit" class="btn btn-sm btn-danger mb-2">
                  Hapus
                </button>                    
              </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\APLIKASI\toko\resources\views/image/index.blade.php ENDPATH**/ ?>