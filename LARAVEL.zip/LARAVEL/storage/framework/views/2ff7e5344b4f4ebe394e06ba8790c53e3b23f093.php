<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col">
      <h1>Tentang Kami</h1>
      <h3>Ini Adalah Tugas UAS </h3>
      <p> Website Sederhana ini Berbasis Laravel 8 Dengan CRUD & Database YAng telah di kerjakan Oleh Misbakhul Fuad & Sally </p>
      <p>Tugas           : Framework</p>
      <p>Dosen Pengampu  :Eko Julianto M.kom </p>
      <p>Terima Kasih kepada semua pihak yang ikut mendukung adanya website sederhana ini</p>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\APLIKASI\toko\resources\views/homepage/about.blade.php ENDPATH**/ ?>