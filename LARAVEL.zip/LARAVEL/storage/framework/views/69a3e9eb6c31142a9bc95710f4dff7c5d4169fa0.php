<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- table produk -->
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Produk</h4>
          <div class="card-tools">
            <a href="<?php echo e(route('promo.create')); ?>" class="btn btn-sm btn-primary">
              Baru
            </a>
          </div>
        </div>
        <div class="card-body">
          <form action="#">
            <div class="row">
              <div class="col">
                <input type="text" name="keyword" id="keyword" class="form-control" placeholder="ketik keyword disini">
              </div>
              <div class="col-auto">
                <button class="btn btn-primary">
                  Cari
                </button>
              </div>
            </div>
          </form>
        </div>
        <div class="card-body">
          <?php if($message = Session::get('error')): ?>
              <div class="alert alert-warning">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
              </div>
          <?php endif; ?>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="50px">No</th>
                  <th>Gambar</th>
                  <th>Kode</th>
                  <th>Harga Awal</th>
                  <th>Nama</th>
                  <th>Diskon</th>
                  <th>Harga Akhir</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $itempromo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                  <?php echo e(++$no); ?>

                  </td>
                  <td>
                    <?php if($promo->produk->foto != null): ?>
                    <img src="<?php echo e(\Storage::url($promo->produk->foto)); ?>" alt="<?php echo e($promo->produk->nama_produk); ?>" width='150px' class="img-thumbnail">
                    <?php endif; ?>
                  </td>
                  <td>
                  <?php echo e($promo->produk->kode_produk); ?>

                  </td>
                  <td>
                  <?php echo e($promo->produk->nama_produk); ?>

                  </td>
                  <td>
                  <?php echo e(number_format($promo->harga_awal, 2)); ?>

                  </td>
                  <td>
                  <?php echo e(number_format($promo->diskon_nominal, 2)); ?> (<?php echo e($promo->diskon_persen); ?>%)
                  </td>
                  <td>
                  <?php echo e(number_format($promo->harga_akhir, 2)); ?>

                  </td>
                  <td>
                    <a href="<?php echo e(route('promo.edit', $promo->id)); ?>" class="btn btn-sm btn-primary mr-2 mb-2">
                      Edit
                    </a>
                    <form action="<?php echo e(route('promo.destroy', $promo->id)); ?>" method="post" style="display:inline;">
                      <?php echo csrf_field(); ?>
                      <?php echo e(method_field('delete')); ?>

                      <button type="submit" class="btn btn-sm btn-danger mb-2">
                        Hapus
                      </button>                    
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($itempromo->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\latihan edit\toko\resources\views/promo/index.blade.php ENDPATH**/ ?>