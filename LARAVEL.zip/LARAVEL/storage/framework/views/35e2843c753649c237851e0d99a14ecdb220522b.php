<div class="container">
    <div class="row">
      <div class="col">
        <hr />
        <h9><b><i>@Tugas  UAS Framework 2022</i></b></h9>
      </div>
    </div>
  </div><?php /**PATH C:\Users\DELL\Documents\latihan edit\toko\resources\views/layouts/footer.blade.php ENDPATH**/ ?>