<h1>Selamat Datang di Kelas</h1>
<p>
  Ini adalah paragraph
</p>
<p>
  Halo nama saya adalah : <?php echo e($nama); ?>

</p><?php /**PATH D:\APLIKASI\toko\resources\views/beranda.blade.php ENDPATH**/ ?>