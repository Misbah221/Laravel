<div class="container">
    <div class="row">
      <div class="col">
        <hr />
        <h9><b><i>@Tugas UAS Framework 2022</i></b></h9>
      </div>
    </div>
  </div>