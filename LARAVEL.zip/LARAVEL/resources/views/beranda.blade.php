<h1>Selamat Datang di Kelas</h1>
<p>
  Ini adalah paragraph
</p>
<p>
  Halo nama saya adalah : {{ $nama }}
</p>