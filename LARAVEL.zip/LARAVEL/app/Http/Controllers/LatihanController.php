<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LatihanController extends Controller
{
    public function index() {
        return "oke, ini dari controller";
    }
    public function beranda() {
        $data = array('nama' => 'Misbakhul Fuad');
        return view('beranda', $data);
}
}